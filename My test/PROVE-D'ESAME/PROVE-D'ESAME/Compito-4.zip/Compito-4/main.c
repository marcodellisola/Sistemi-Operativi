#include "sensore.h"
#include "aggregatore.h"
#include "collettore.h"

#include <stdio.h>
#include <stdlib.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <unistd.h>
#include <sys/wait.h>

int main() {


    /* TBD: Creare le code di messaggi, 
     * e avviare i processi sensore, aggregatore, e collettore 
     */
    
}