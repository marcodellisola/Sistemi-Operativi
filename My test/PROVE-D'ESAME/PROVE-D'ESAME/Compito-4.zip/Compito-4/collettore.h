#ifndef _COLLETTORE_H_
#define _COLLETTORE_H_

void collettore(int id_coda_collettore);

#endif